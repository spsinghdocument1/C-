﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NKB_STG_QtyCheck
{
    class Program
    {


        struct NFToken
        {
            public short TK1MIN;
            public short TK2MIN;
            public short TK3MIN;

            public short TK1MAX;
            public short TK2MAX;
            public short TK3MAX;

            public short MINTK1BIDQTY;
            public short MINTK2BIDQTY;
            public short MINTK3BIDQTY;

            public short NetTradedTK1;
            public short NetTradedTK2;
            public short NetTradedTK3;

            public short CurTradedTK1;
            public short CurTradedTK2;
            public short CurTradedTK3;

            public short MINHITTK1;
            public short MINHITTK2;
            public short MINHITTK3;
        }

        static void Main(string[] args)
        {
            NFToken _nfToken= new NFToken();

            short Ratio1 = 2;
            short Ratio2 = 3;
            short Ratio3 = 5;

            short MinQty = 10;
            short MaxQty = 25;
            short LastMax = 0;


            _nfToken.TK1MIN = (short)(MinQty * Ratio1);
            _nfToken.TK2MIN = (short)(MinQty * Ratio2);
            _nfToken.TK3MIN = (short)(MinQty * Ratio3);

            _nfToken.TK1MAX = (short)(MaxQty * Ratio1);
            _nfToken.TK2MAX = (short)(MaxQty * Ratio2);
            _nfToken.TK3MAX = (short)(MaxQty * Ratio3);

            //_nfToken.NetTradedTK1 = 0;
            //_nfToken.NetTradedTK2 = 0;
            //_nfToken.NetTradedTK3 = 0;

            //_nfToken.CurTradedTK1 = 0;
            //_nfToken.CurTradedTK2 = 0;
            //_nfToken.CurTradedTK3 = 0;

            if (LastMax != _nfToken.TK1MAX)
            {
                BidQtyInit(ref _nfToken);
                UpdateQty(ref _nfToken);
            }

            while (_nfToken.NetTradedTK1 < _nfToken.TK1MAX)
            {
                _nfToken.NetTradedTK1 += 1;
                _nfToken.CurTradedTK1 += 1;

                Console.WriteLine("Current Traded Qty " + _nfToken.CurTradedTK1 + " Net Traded Qty " + _nfToken.NetTradedTK1);

                UpdateQty(ref _nfToken);
                Console.WriteLine("TK2 Hit Qty " + _nfToken.MINHITTK2 + " TK3 Hit Qty " +_nfToken.MINHITTK3 );
                _nfToken.NetTradedTK2 += _nfToken.MINHITTK2;
                _nfToken.CurTradedTK2 += _nfToken.MINHITTK2;

                _nfToken.NetTradedTK3 += _nfToken.MINHITTK3;
                _nfToken.CurTradedTK3 += _nfToken.MINHITTK3;

                Console.WriteLine("TK2 CurTraded Qty " + _nfToken.CurTradedTK2 + " TK3 CurTraded Qty " + _nfToken.CurTradedTK3);
                Console.WriteLine("TK2 NetTraded Qty " + _nfToken.NetTradedTK2 + " TK3 NetTraded Qty " + _nfToken.NetTradedTK3);

                Console.WriteLine("");
                Console.ReadLine();

                if (_nfToken.MINTK1BIDQTY == _nfToken.CurTradedTK1)
                {
                    Console.WriteLine("MINTK1BIDQTY " + _nfToken.MINTK1BIDQTY + " CurTradedTK1 " + _nfToken.CurTradedTK1);
                    _nfToken.CurTradedTK1 = 0;
                    _nfToken.CurTradedTK2 = 0;
                    _nfToken.CurTradedTK3 = 0;

                    BidQtyInit(ref _nfToken);
                    Console.WriteLine("New Order Reset occurred");
                    Console.WriteLine("");
                }

            }
            Console.ReadLine();
        }


        private static void BidQtyInit(ref NFToken _nfToken)
        {
            _nfToken.MINTK1BIDQTY = (short)Math.Min((_nfToken.TK1MAX - _nfToken.NetTradedTK1), _nfToken.TK1MIN);
            _nfToken.MINTK2BIDQTY = (short)(_nfToken.MINTK1BIDQTY < _nfToken.TK1MIN ? (_nfToken.TK2MAX - _nfToken.NetTradedTK2) : Math.Min((_nfToken.TK2MAX - _nfToken.NetTradedTK2), _nfToken.TK2MIN));
            _nfToken.MINTK3BIDQTY = (short)(_nfToken.MINTK1BIDQTY < _nfToken.TK1MIN ? (_nfToken.TK3MAX - _nfToken.NetTradedTK3) : Math.Min((_nfToken.TK3MAX - _nfToken.NetTradedTK3), _nfToken.TK3MIN));

        }

        private static void UpdateQty(ref NFToken _nfToken)
        {
           
            _nfToken.MINHITTK2 =
                (short)
                    (_nfToken.CurTradedTK1 < _nfToken.MINTK1BIDQTY
                        ? (_nfToken.CurTradedTK2 < _nfToken.MINTK2BIDQTY
                            ? Math.Min((_nfToken.MINTK2BIDQTY - _nfToken.CurTradedTK2),
                                (_nfToken.CurTradedTK1 - _nfToken.CurTradedTK2))
                            : 0)
                        : (_nfToken.MINTK2BIDQTY - _nfToken.CurTradedTK2));

            _nfToken.MINHITTK3 =
    (short)
        (_nfToken.CurTradedTK1 < _nfToken.MINTK1BIDQTY
            ? (_nfToken.CurTradedTK3 < _nfToken.MINTK3BIDQTY
                ? Math.Min((_nfToken.MINTK3BIDQTY - _nfToken.CurTradedTK3),
                    (_nfToken.CurTradedTK1 - _nfToken.CurTradedTK3))
                : 0)
            : (_nfToken.MINTK3BIDQTY - _nfToken.CurTradedTK3));

        }
    }
}
